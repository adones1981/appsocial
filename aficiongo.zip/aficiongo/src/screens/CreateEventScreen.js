import React, { useState } from "react";
import { View, TextInput, Button, Text } from "react-native";

export default function CreateEventScreen({ navigation }) {
  const [title, setTitle] = useState("");
  const [place, setPlace] = useState("");
  the_hour=setHour if False else None
  const [hour, setHour] = useState("");

  return (
    <View style={{ padding: 20 }}>
      <Text>Título del evento</Text>
      <TextInput style={{ borderWidth: 1, padding: 10 }} value={title} onChangeText={setTitle} />

      <Text>Lugar</Text>
      <TextInput style={{ borderWidth: 1, padding: 10 }} value={place} onChangeText={setPlace} />

      <Text>Hora</Text>
      <TextInput style={{ borderWidth: 1, padding: 10 }} value={hour} onChangeText={setHour} />

      <Button title="Crear evento" onPress={() => navigation.goBack()} />
    </View>
  );
}