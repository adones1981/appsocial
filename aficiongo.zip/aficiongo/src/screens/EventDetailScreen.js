import React from "react";
import { View, Text, Button } from "react-native";

export default function EventDetailScreen({ route, navigation }) {
  const { event } = route.params;
  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 28 }}>{event.title}</Text>
      <Text>Lugar: {event.place}</Text>
      <Text>Hora: {event.hour}</Text>
      <Button title="Unirse al chat" onPress={() => navigation.navigate("Chat")} />
    </View>
  );
}