import React from "react";
import { View, Text, Button, ScrollView } from "react-native";
import EventCard from "../components/EventCard";

export default function HomeScreen({ navigation }) {
  const events = [
    { id: 1, title: "Partido de fútbol", place: "Cancha municipal", hour: "18:00" },
    { id: 2, title: "Trekking cerro Manquehue", place: "Entrada principal", hour: "08:00" }
  ];
  return (
    <ScrollView style={{ padding: 20 }}>
      <Button title="Crear nuevo evento" onPress={() => navigation.navigate("CrearEvento")} />
      <Text style={{ fontSize: 24, marginTop: 20 }}>Eventos disponibles</Text>
      {events.map((ev) => (
        <EventCard key={ev.id} event={ev} onPress={() => navigation.navigate("Detalle", { event: ev })} />
      ))}
    </ScrollView>
  );
}