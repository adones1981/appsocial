import React from "react";
import { View, Text, TouchableOpacity } from "react-native";

export default function EventCard({ event, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={{ padding: 15, marginVertical: 10, borderWidth: 1, borderRadius: 10 }}>
      <Text style={{ fontSize: 20 }}>{event.title}</Text>
      <Text>{event.place}</Text>
      <Text>{event.hour}</Text>
    </TouchableOpacity>
  );
}